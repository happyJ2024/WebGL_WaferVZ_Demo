/**
 * Created by yjbian on 1/4/15.
 */

var GRID_LINE_COLOR = 0x0c0c0c; //black

var DIE_COLOR = 0x0c0c0c;

var CUBE_DIE_BASE_COLOR = 0x0c0c0c;

var CUBE_DEFAULT_COLOR = null;

var CUBE_MARK_ERROR_SELECT_COLOR = 0xFF0000; //red
var CUBE_PICK_UP_SELECT_COLOR = 0x38ACEC; //blue

var CUBE_MARK_ERROR_DESELECT_COLOR = null;
var CUBE_PICK_UP_DESELECT_COLOR = null;

var GOLDEN = 0xFFFF44; //gold